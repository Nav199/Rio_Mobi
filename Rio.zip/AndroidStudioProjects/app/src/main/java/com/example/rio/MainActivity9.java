package com.example.rio;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity9 extends AppCompatActivity {
    private Button addCityButton;
    private LinearLayout cityInputContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main9);

        addCityButton = findViewById(R.id.addCityButton);
        cityInputContainer = findViewById(R.id.cityInputContainer);

        addCityButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Quando o botão é clicado, adicione um novo campo de input para cidades
                EditText cityEditText = new EditText(MainActivity9.this);
                cityEditText.setLayoutParams(new LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                ));
                cityEditText.setHint("Digite o nome da cidade");
                cityInputContainer.addView(cityEditText);
            }
        });
    }
}
