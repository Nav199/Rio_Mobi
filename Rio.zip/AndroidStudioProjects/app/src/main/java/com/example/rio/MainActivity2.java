package com.example.rio;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity2 extends AppCompatActivity {
    private EditText nomeEditText;
    private EditText cpfEditText;
    private EditText rgEditText;
    private EditText telefoneEditText;
    private EditText emailEditText;
    private EditText senhaEditText;

    // database
    private FirebaseDatabase database = FirebaseDatabase.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        // ID's diversos
        TextView linkTextView = findViewById(R.id.textViewLogin);

        Button btnCadastrar = findViewById(R.id.btnCadastrar);

        TextView link_principal = findViewById(R.id.Return_principal_pass);

        // Links para outras telas
        linkTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity2.this, MainActivity5.class);
                startActivity(intent);
            }
        });

        link_principal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity2.this, MainActivity.class);
                startActivity(intent);
            }
        });
        // ação para ir para a tela de pesquisar passagem
        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cadastrar();
            }
        });
    }

    private void cadastrar() {
        // Obter valores dos campos de entrada
        nomeEditText = findViewById(R.id.Id_Nome);
        cpfEditText = findViewById(R.id.Id_Cpf);
        rgEditText = findViewById(R.id.Id_Rg);
        telefoneEditText = findViewById(R.id.Num_tele);
        emailEditText = findViewById(R.id.Id_gmail);
        senhaEditText = findViewById(R.id.ID_SENHA);

        String nome = nomeEditText.getText().toString();
        String cpf = cpfEditText.getText().toString();
        String rg = rgEditText.getText().toString();
        String telefone = telefoneEditText.getText().toString();
        String email = emailEditText.getText().toString();
        String senha = senhaEditText.getText().toString();

        User user = new User(nome, cpf, rg, telefone, email, senha);
        user.Salvar();

        Log.d("TAG", "Dados do usuário salvos no banco de dados.");

        // Navegar para a próxima tela (MainActivity6)
        Intent intent = new Intent(MainActivity2.this, MainActivity6.class);
        startActivity(intent);
    }
}
