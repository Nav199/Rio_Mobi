package com.example.rio;

import android.widget.EditText;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
public class User {
    // Classe do Usuário
    private String nome;
    private String cpf;
    private String rg;
    private String telefone;
    private String email;

    private String Senha;

    public User(EditText nomeEditText, EditText cpfEditText, EditText rgEditText, EditText telefoneEditText, EditText emailEditText, EditText senhaEditText) {
        // Construtor vazio necessário para Firebase Realtime Database.
    }

    public User(String nome, String cpf, String rg, String telefone, String email, String Senha) {
        this.nome = nome;
        this.cpf = cpf;
        this.rg = rg;
        this.telefone = telefone;
        this.email = email;
        this.Senha = Senha;
    }

    public void Salvar(){
        DatabaseReference UserRef = FirebaseDatabase.getInstance().getReference("Cadastro_user");

        String id_user = UserRef.push().getKey();

        // Criando um objeto User com os dados fornecidos
        User user = new User(nome, cpf, rg, telefone, email, Senha);

        // Salvando o usuário no banco de dados usando a chave única
        UserRef.child(id_user).setValue(user);
    }
}
